import { StyleSheet, Text, View, TextInput, Button, Alert } from 'react-native';
import React, { useState } from 'react';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [nome, setNome] = useState('');
  const press = () => {
    Alert.alert('Seu nome é:', nome);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}> NOME </Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu nome:"
        value={nome}
        onChangeText={setNome}
      />
      <Button
        title="Clique e revele"
        onPress={press}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff',

    padding: 8,
  },
  paragraph: {
    color: '#000000',
    margin: 24,
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
