import { StyleSheet, Text, View, TextInput, ScrollView, Button, FlatList } from 'react-native';
import React, { useState } from 'react';
import { SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [itens, setItens] = useState([]);
  const [texto, setTexto] = useState('');

  function adicionarItem() {
    setItens([...itens, texto]);
    setTexto('');
  }
  
  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <TextInput
          style={styles.input}
          placeholder="Digite um item..."
          value={texto}
          onChangeText={setTexto} />
        <Button title="Adicionar" onPress={adicionarItem} />
        <ScrollView >
          {itens.map((item, index) => (
          <Text key={index} style={styles.item}>
          {item}
          </Text>
          ))}
        </ScrollView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    padding: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#99999',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    backgroundColor: '#ffffff',
  },
  item: {
    fontSize: 18,
    padding: 10,
    backgroundColor: '#B3EBF2',
    marginTop: 10,
    borderRadius: 5,
  },
});
