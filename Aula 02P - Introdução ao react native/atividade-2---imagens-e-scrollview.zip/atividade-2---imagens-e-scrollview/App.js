import { StyleSheet, Text, View, ScrollView, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

const img1 = require('./assets/img1.jpg');
const img2 = require('./assets/img2.jpg');
const img3 = require('./assets/img3.jpg');
const img4 = require('./assets/img4.png');
const img5 = require('./assets/img5.png');
const img6 = require('./assets/img6.png');

export default function App() {
  return (
    
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Image source={img1} style={styles.image} />
        <Image source={img2} style={styles.image} />
        <Image source={img3} style={styles.image} />
        <Image source={img4} style={styles.image} />
        <Image source={img5} style={styles.image} />
        <Image source={img6} style={styles.image} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  image: {
    width: '100%',
    height: 325,
    marginBottom: 15,
    
  },
});
